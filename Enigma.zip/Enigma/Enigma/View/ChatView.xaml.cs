﻿using System;
using Enigma.ViewModel;
using System.Windows;

namespace Enigma.View
{
	/// <summary>
	/// Interaction logic for ChatView.xaml
	/// </summary>
	public partial class ChatView : Window
	{
		public ChatView()
		{
			InitializeComponent();
			UserPanel.DataContext = ClientLoginViewModel.SingleCLientInstance;
			MessageListView.ItemsSource = ViewModelBase.RecievedDataCollection;
			UsersListView.ItemsSource = ViewModelBase.UserCollection;

			Closing += ViewModelBase.OnClosing;

			MessageInput.LostFocus += MessageInput_LostFocus;
		}

		private void MessageInput_LostFocus( object sender, RoutedEventArgs e )
		{
			MessageInput.Text = String.Empty;
		}
	}
}
