﻿using Enigma.ViewModel;
using System.Windows;

namespace Enigma.View
{
	/// <summary>
	/// Interaction logic for PortalView.xaml
	/// </summary>
	public partial class PortalView : Window
	{
		public PortalView()
		{
			InitializeComponent();
			ViewModelBase.PortalView = this;
			Loaded += PortalView_Loaded;
		}

		private void PortalView_Loaded( object sender, RoutedEventArgs e )
		{
			if(ViewModelBase.UserExists)
			{
				MessageBox.Show("this name is taken");
			}
		}
	}
}
