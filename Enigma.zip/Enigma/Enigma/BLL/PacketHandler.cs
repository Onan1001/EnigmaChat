﻿using Enigma.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Enigma.BLL
{
    public class PacketHandler
    {
        #region Private Members
        private DataIdentifier _dataIdentifier;
        private string _name;
        private string _message;
        #endregion

        #region Public Properties
        public DataIdentifier ChatDataIdentifier
        {
            get => _dataIdentifier;
            set => _dataIdentifier = value;
        }

        public string ChatName
        {
            get => _name;
            set => _name = value;
        }

        public string ChatMessage
        {
            get => _message;
            set => _message = value;
        }

        private string _usersArray;
        public string UsersArray
        {
            get => _usersArray;
            set => _usersArray = value;
        }

        #endregion

        #region Methods

        // Default Constructor
        public PacketHandler()
        {
            _dataIdentifier = DataIdentifier.Null;
            _message = null;
            _name = null;
            _usersArray = null;
        }

        public PacketHandler(byte[] dataStream)
        {
            // Read the data identifier from the beginning of the stream (4 bytes)
            _dataIdentifier = (DataIdentifier)BitConverter.ToInt32(dataStream, 0);

            // Read the length of the name (4 bytes)
            var nameLength = BitConverter.ToInt32(dataStream, 4);

            // Read the length of the message (4 bytes)
            var msgLength = BitConverter.ToInt32(dataStream, 8);

            var extraDataLength = BitConverter.ToInt32(dataStream, 12);

            // Read the name field
            if (nameLength > 0)
                _name = Encoding.UTF8.GetString(dataStream, 16, nameLength);
            else
                _name = null;

            if (msgLength > 0)
                _message = Encoding.UTF8.GetString(dataStream, (16 + nameLength), msgLength);
            else
                _message = null;

            // Read the UsersArray field
            if (extraDataLength > 0)
                _usersArray = Encoding.UTF8.GetString(dataStream, (16 + nameLength + msgLength), extraDataLength);
            else
                _usersArray = null;
        }

        // Converts the packet into a byte array for sending/receiving 
        public byte[] GetDataStream()
        {
            var dataStream = new List<byte>();

            // Add the dataIdentifier
            dataStream.AddRange(BitConverter.GetBytes((int)_dataIdentifier));

            // Add the name length
            if (_name != null)
                dataStream.AddRange(BitConverter.GetBytes(_name.Length));
            else
                dataStream.AddRange(BitConverter.GetBytes(0));

            // Add the message length
            if (_message != null)
                dataStream.AddRange(BitConverter.GetBytes(_message.Length));
            else
                dataStream.AddRange(BitConverter.GetBytes(0));

            // Add the name length
            if (_usersArray != null)
                dataStream.AddRange(BitConverter.GetBytes(_usersArray.Length));
            else
                dataStream.AddRange(BitConverter.GetBytes(0));

            // Add the name
            if (_name != null)
                dataStream.AddRange(Encoding.UTF8.GetBytes(_name));

            // Add the message
            if (_message != null)
                dataStream.AddRange(Encoding.UTF8.GetBytes(_message));

            // Add the message
            if (_usersArray != null)
                dataStream.AddRange(Encoding.UTF8.GetBytes(_usersArray));

            return dataStream.ToArray();
        }

        #endregion
    }
}
