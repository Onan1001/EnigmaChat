﻿using Enigma.ViewModel;

namespace Enigma.Models
{
	public class ClientDetails : NotifyOnChange
	{

		private string _username;

		public string Username
		{
			get => _username;
			set
			{
				_username = value;
				OnChange();
			}
		}

		private string _message;

		public string Message
		{
			get => _message;
			set
			{
				_message = value;
				OnChange();
			}
		}


		private string serverEndPoint;

		public string ServerEndPoint
		{
			get => serverEndPoint;
			set
			{
				serverEndPoint = value;
				OnChange();
			}
		}

	}	
}
