﻿namespace Enigma.Model
{
    public enum DataIdentifier
    {
        Message,
        LogIn,
        LogOut,
        Null
    }
}
