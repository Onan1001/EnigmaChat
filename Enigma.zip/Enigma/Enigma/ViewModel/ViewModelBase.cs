﻿using Enigma.BLL;
using Enigma.Models;
using Enigma.View;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Windows;
using Enigma.Model;

namespace Enigma.ViewModel
{
	public class ViewModelBase : NotifyOnChange
	{
		public static bool UserExists;
		private static bool _clientDisconnected;
		public static PortalView PortalView {get;set;}
		public static ChatView ChatView {get;set;}


		// Client socket
		public static Socket clientSocket;
		// Server End Point
		public static EndPoint epServer;

		// Data stream
		public static byte[] dataStream = new byte[1024];

		public static ObservableCollection<PacketHandler> RecievedDataCollection 
			= new ObservableCollection<PacketHandler>();

		public static ObservableCollection<string> UserCollection
			= new ObservableCollection<string>();


		public static void ClientConnection(ClientDetails clientDetail)
		{
			try
			{
				_clientDisconnected = false;
				clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

				// Initialise a packet object to store the data to be sent
				var sendData = new PacketHandler
				{
					ChatName = clientDetail.Username,
					ChatMessage = EncryptHandler.Encrypt("confimation",EncryptHandler.key),
                    ChatDataIdentifier = DataIdentifier.Null,
					UsersArray = null,
				};

				// Initialise the IPEndPoint for the server and use port 30000
				var server = new IPEndPoint( IPAddress.Parse( clientDetail.ServerEndPoint ), 30000);

				// Initialise the EndPoint for the server
				epServer = (EndPoint)server;

				// Get packet as byte array
				byte[] data = sendData.GetDataStream();

				// Send data to server
				clientSocket.BeginSendTo(data, 0, data.Length, SocketFlags.None, epServer, SendData, null);

				// Initialise data stream
				dataStream = new byte[1024];

				// Begin listening for broadcasts
				clientSocket.BeginReceiveFrom( dataStream, 0, dataStream.Length, SocketFlags.None, ref epServer, ReceiveData, null);
				//re-send to get postback

				var reSend = new PacketHandler
				{
					ChatName = clientDetail.Username,
					ChatMessage = EncryptHandler.Encrypt("login",EncryptHandler.key),
					ChatDataIdentifier = DataIdentifier.LogIn,
					UsersArray = null,
				};

				byte[] reData = reSend.GetDataStream();

				clientSocket.BeginSendTo(reData, 0, reData.Length, SocketFlags.None, epServer, SendData, null);

			}
			catch (Exception ex)
			{
				MessageBox.Show("Connection Error: " + ex.Message);
			}
			finally
			{
				if(clientSocket != null)
				{
					ChatView = new ChatView();
					ChatView.Show();
					PortalView.Hide();
				}
			}
		}

		public static void SendData(IAsyncResult ar)
		{
			if(_clientDisconnected) return;
			try
			{
				clientSocket.EndSend(ar);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Send Data: " + ex.Message, "UDP Client");
			}
		}
		public static void ReceiveData(IAsyncResult ar)
		{
			Debug.WriteLine("Incomming!");
			if(_clientDisconnected) return;
			try
			{				
				// Receive all data
				clientSocket.EndReceive(ar);
				Application.Current.Dispatcher.Invoke( 
					delegate {
					// Initialise a packet object to store the received data

						var dataRecieved = new PacketHandler( dataStream );
						var decryptMsg = EncryptHandler.Decrypt(dataRecieved.ChatMessage, EncryptHandler.key);
						dataRecieved.ChatMessage = decryptMsg;

						if ( dataRecieved.ChatMessage == "Not Available!" 
						     && dataRecieved.ChatDataIdentifier == DataIdentifier.Null)
						{
							UserExists = true;
							LogOut();
							ChatView.Hide();
							PortalView.Show();
							return;
						}
						if(dataRecieved.UsersArray != null)
						{
							RecievedDataCollection.Add( dataRecieved );
							UserCollection.Clear();
							var splitUsers = dataRecieved.UsersArray.Split(',');
							var distinctUsers = (splitUsers.Select(i => i)).Distinct();
							foreach (var item in distinctUsers)
							{
								UserCollection.Add(item.Trim());
							}
						}

					});
				// Reset data stream
				dataStream = new byte[1024];
				// Continue listening for broadcasts

				clientSocket.BeginReceiveFrom(dataStream, 0, dataStream.Length, SocketFlags.None, ref epServer, ReceiveData, null);

			}
			catch (Exception ex)
			{
				if(UserExists)
					MessageBox.Show("Please Choose another username to procced", "Username not available!");
				else
					MessageBox.Show("Receive Data: " + ex.Message, "UDP Client");
				
			}
		}

		public static void OnClosing(object sender, CancelEventArgs e)
		{
			LogOut();
		}

		public static void LogOut()
		{
			try
			{
				_clientDisconnected = true;
				if (clientSocket != null)
				{
					// Initialise a packet object to store the data to be sent
					var sendData = new PacketHandler
					{
						ChatDataIdentifier = DataIdentifier.LogOut,
						ChatName = ClientLoginViewModel.SingleCLientInstance.Username,
						ChatMessage = null
					};

					// Get packet as byte array
					byte[] byteData = sendData.GetDataStream();

					// Send packet to the server
					clientSocket.SendTo(byteData, 0, byteData.Length, SocketFlags.None, epServer);

					// Close the socket
					clientSocket.Close();
					
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Closing Error: " + ex.Message, "UDP Client");
			}
			finally
			{
				Debug.WriteLine("Setting client disconnect");
			}
		}
	}
}
