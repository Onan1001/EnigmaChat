﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Enigma.ViewModel
{
    public class NotifyOnChange : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void OnChange([CallerMemberName]string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
