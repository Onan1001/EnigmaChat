﻿using Enigma.Models;
using System.Windows.Input;

namespace Enigma.ViewModel
{
	public class ClientLoginViewModel
	{


		public static ClientDetails SingleCLientInstance {get;set;}

		public ICommand ClientLoginCLickCommand { get; set; }

		public ClientLoginViewModel()
		{
			ClientLoginCLickCommand = new RelayCommand(ClickAction, CanClick);
		}

		private void ClickAction(object parameter)
		{		
			SingleCLientInstance = parameter as ClientDetails;
			if(parameter == null) return;
			ViewModelBase.ClientConnection(SingleCLientInstance);
		}

		private bool CanClick(object parameter)
		{
			return true;
		}
		

	}
}
