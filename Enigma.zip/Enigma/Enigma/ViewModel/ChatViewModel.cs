﻿using Enigma.BLL;
using Enigma.Model;
using Enigma.Models;
using System;
using System.Net.Sockets;
using System.Windows;
using System.Windows.Input;

namespace Enigma.ViewModel
{
    public class ChatViewModel
    {
        public ICommand ClientSendCommand { get; set; }

        public ChatViewModel()
        {
            ClientSendCommand = new RelayCommand(ClickAction, CanClick);
        }

        private void ClickAction(object parameter)
        {
            var message = parameter as string;
            if (parameter == null) return;
            string encrypt = EncryptHandler.Encrypt(message, EncryptHandler.key);
            SendMessage(ClientLoginViewModel.SingleCLientInstance, encrypt, ViewModelBase.clientSocket);
        }

        private bool CanClick(object parameter)
        {
            return true;
        }

        private void SendMessage(ClientDetails clientInfo, string message, Socket cliSocket)
        {
            try
            {
                // Initialise a packet object to store the data to be sent
                var dataPacket = new PacketHandler();
                dataPacket.ChatName = clientInfo.Username;
                dataPacket.ChatMessage = message;
                dataPacket.ChatDataIdentifier = DataIdentifier.Message;
                // Get packet as byte array
                var byteData = dataPacket.GetDataStream();
                // Send packet to the server
                cliSocket.BeginSendTo(byteData, 0, byteData.Length, SocketFlags.None, ViewModelBase.epServer, ViewModelBase.SendData, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Send Error: " + ex.Message, "UDP Client");
            }
        }
    }
}
